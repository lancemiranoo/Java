package spring.security.database.databasesecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabasesecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
